# Age Widget

A minimal Android home-screen widget that shows your age as "Xy Xm Xd",
counting up from a birth date of **9 October 2002**.

## Project layout
```
AgeWidget/
  app/
    src/main/
      java/com/rathin/agewidget/AgeWidgetProvider.kt   <- the age calculation + widget update logic
      res/layout/age_widget_layout.xml                  <- what the widget looks like
      res/xml/age_widget_info.xml                        <- widget size/update settings
      AndroidManifest.xml
  build.gradle, settings.gradle                          <- project config
```

## How to build and install (from VS Code / terminal)

1. Open this folder in VS Code (`File > Open Folder`).
2. Open a terminal inside VS Code (`` Ctrl+` ``).
3. Generate the Gradle wrapper jar (one-time, requires Gradle installed globally OR
   just download `gradle-8.7` and run `gradle wrapper` once inside this folder):
   ```
   gradle wrapper --gradle-version 8.7
   ```
   This creates `gradlew` / `gradlew.bat` and the wrapper jar for you.
4. Connect your Nothing phone via USB with USB debugging enabled, and confirm it's detected:
   ```
   adb devices
   ```
   You should see your device listed.
5. Build and install directly onto your phone:
   ```
   ./gradlew installDebug
   ```
   (On Windows: `gradlew.bat installDebug`)
6. On your phone: long-press the home screen → Widgets → find "Age Widget" → drag it onto your home screen.

## Changing the birth date
Open `AgeWidgetProvider.kt` and edit the `BIRTH_DATE` line. The certificate
date (14 April 2005) is already there, commented out, if you ever want to swap.

## Notes
- Android limits automatic widget refreshes to every 30 minutes minimum
  (`updatePeriodMillis` in `age_widget_info.xml`), which is more than enough
  since the value only changes once a day.
- If `adb devices` shows nothing: check the USB cable supports data transfer,
  and that you tapped "Allow" on the USB debugging prompt on your phone.
